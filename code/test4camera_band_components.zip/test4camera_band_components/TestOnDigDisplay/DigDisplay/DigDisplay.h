// This is a library for the 4 digital display

#if ARDUINO >= 100
    #include <Arduino.h>
#else
    #include <WProgram.h>
#endif

class DigDisplay {
    public:
        DigDisplay(int terminals[]);
        void disp(int n, bool dot);
    private:
        int terms[12];
        int digits[4];
};